﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuynhDinh_BusinessLogic.Model {

    /// <summary>
    /// Set of car type values
    /// </summary>
    public enum CarType {
        Hatchback, Sedan, MPV
    }
}
